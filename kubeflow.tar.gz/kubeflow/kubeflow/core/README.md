<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**  *generated with [DocToc](https://github.com/thlorenz/doctoc)*

- [core](#core)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

# core

This ksonnet package contains kubeflow core prototypes such as jupyterhub, ambassador, spartakus, etc. You can install this using `ks pkg install kubeflow/core`. `ks prototype list` should list the available prototypes. `ks prototype describe <name>` should describe the prototype.
