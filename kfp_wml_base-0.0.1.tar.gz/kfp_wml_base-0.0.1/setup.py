import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="kfp_wml_base",
    version="0.0.1",
    author="Adrian Zhuang",
    author_email="wzhuang@us.ibm.com",
    description="Base container for KFP on WML",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.ibm.com/AIOpsPipeline/kfp-samples/kfp_wml_base",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=[
        'kfp',
        'kubernetes'
    ]
)