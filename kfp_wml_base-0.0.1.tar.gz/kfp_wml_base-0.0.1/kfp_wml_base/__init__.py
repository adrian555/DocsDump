name = "kfp_wml_base"

import kfp.dsl as dsl
from kubernetes import client as k8s_client
import os

def wml_base_op(name, image, command, arguments, file_outputs, secrets='test-secret'):
    return dsl.ContainerOp(
        name = name,
        image = image,
        command = command,
        arguments = arguments,
        file_outputs = file_outputs) \
        .add_volume(k8s_client.V1Volume(name=secrets,
                                        secret=k8s_client.V1SecretVolumeSource(
                                        secret_name=secrets))) \
        .add_volume_mount(k8s_client.V1VolumeMount(mount_path='/app/secrets', name=secrets))

def wml_config_op(arguments, file_outputs):
    args = ['/app/config.py'] + arguments
    return dsl.ContainerOp(
        name = "config",
        image = "aipipeline/wml-config",
        command = ['python3'],
        arguments = args,
        file_outputs = file_outputs)

def get_secret_name(git_username):
    import uuid
    return 'secret-' + git_username + '-' + str(uuid.uuid1()).split('-')[0]